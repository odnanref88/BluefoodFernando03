package br.com.softblue.bluefood.domain.pagamento;

public enum BandeiraCartao {
    VISA, MASTER, ELO, AMEX;
	
	
}
