package br.com.softblue.bluefood.domain.pagamento;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@SuppressWarnings("unused")
public interface PagamentoRepository extends JpaRepository<Pagamento, Integer> {
    
	
}
